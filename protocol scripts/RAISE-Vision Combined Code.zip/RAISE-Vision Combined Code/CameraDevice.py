# Camera Class
from ADC import ReadableDevice
from PIL import Image, ImageTk
from time import sleep
from threading import Lock, Thread
from typing import Generator
import numpy as np
import tkinter as tk
import cv2

class ImageCaptureError(Exception):
    pass

class CameraDevice(ReadableDevice):
    num_devices: int = 0
    def __init__(self, cam_idx: int = 0, name: str = None) -> None:
        CameraDevice.num_devices += 1
        if name is None:
            self.name = f'Camera {CameraDevice.num_devices}'
        else:
            self.name = name
        self.camera = None
        try:
            self.open(cam_idx)
        except:
            SystemExit(1)

        if self.camera is not None:
            self.fps = self.camera.get(cv2.CAP_PROP_FPS)
            self.width = self.camera.get(cv2.CAP_PROP_FRAME_WIDTH)
            self.height = self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT)
            #self.feed = self.camera_feed()
    
    def open(self, cam_idx):
        super().open()
        CameraDevice.num_devices += 1
        self.camera = cv2.VideoCapture(cam_idx)
        self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1600)
        self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 1200)
        self.device_id = CameraDevice.num_devices

        if not self.camera.isOpened():
            if not self.camera.open(cam_idx):
                raise IOError(f'Failed to Connect with Camera #{cam_idx}')
    
    def __repr__(self) -> str:
        return f'Capture Device {self.device_id}'

    def get_width(self) -> int:
        return int(self.width)

    def get_height(self) -> int:
        return int(self.height)
    
    def get_fps(self) -> int:
        return int(self.fps)

    def get_name(self) -> str:
        return self.name
    
    def camera_feed(self) -> Generator[np.ndarray, None, None]:
        while True:
            ret, frame = self.camera.read()
            if not ret:
                return None
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # TODO: Try resizing frame here
            yield frame
    
    def read(self, fname: str | None = None):
        ret, frame = self.camera.read()
        if not ret:
            raise ImageCaptureError
        else:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame)
            #yield frame
            if fname is not None:
                img.save(fname)
                print(f'Saved Image: {fname}')

    def close(self):
        self.camera.release()

class Camera:
    def __init__(self, cam_idx: int = 0, name: str = None) -> None:
        self.lock = Lock()
        self.camera = CameraDevice(cam_idx, name)
        self.camera_feed = self.camera.camera_feed()
        self.image_shape, self.image_dtype = self.get_image_shape()
        self.preview = Thread(target=self.launch_preview, name=self.get_camera_name(), daemon=True)
        self.preview.start()
    
    def get_image_shape(self):
        self.lock.acquire()
        frame: np.ndarray = next(self.camera_feed)
        self.lock.release()
        return frame.shape, frame.dtype
    
    def get_camera_name(self) -> str:
        return self.camera.get_name()

    def get_camera_width(self) -> int:
        return self.camera.get_width()
    
    def get_camera_height(self) -> int:
        return self.camera.get_height()
    
    def launch_preview(self) -> None:
        def update(root: tk.Tk, display: tk.Label) -> None:
            self.lock.acquire()

            try:
                frame = next(self.camera_feed)
            except StopIteration:
                return
            img = ImageTk.PhotoImage(Image.fromarray(frame))
            display.image = img
            display.config(image=img)
            self.lock.release()

            root.after(30, update, root, display)

        root = tk.Tk()
        root.title(self.get_camera_name())
        img = ImageTk.PhotoImage(Image.fromarray(np.zeros((self.get_camera_height(), self.get_camera_width(), 3), dtype=np.uint8)))
        display = tk.Label(root, image=img)
        display.config(image=img)
        display.pack()

        root.bind('<Escape>', lambda e: root.quit())
        
        update(root, display)

        root.mainloop()

    def capture_image(self, fname: str = '') -> None | np.ndarray:
        self.lock.acquire()
        frame = next(self.camera_feed)
        self.lock.release()

        if frame is not None:
            img = Image.fromarray(frame)
            if fname == '':
                return img
            img.save(fname)
            print(f'Saved Image: {fname}')
    
    def close(self) -> None:
        self.camera.close()
        del(self.camera_feed)


if __name__ == '__main__':
    cam = Camera(cam_idx=0, name='OT2 Camera 1')
    sleep(5)
    cam.capture_image('./Test_Image.jpg', nt=64)
    sleep(5)
    cam.close()
    
    #cam.write()