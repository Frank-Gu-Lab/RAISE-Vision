from CameraDevice import Camera
from Server import Server
from typing import List
import os

from CurvedSurface_CA_ImageProcessing import analyze_run


class CameraServer(Server):
    def __init__(self, name: str|None = None, port: int = 1200, cam_idx: int =0, camera_name: str = None) -> None:
        super().__init__(name, port)
        self.set_camera(cam_idx, camera_name)

    def set_camera(self, cam_idx: int = 0, name: str = None) -> None:
        self.camera: Camera = Camera(cam_idx=cam_idx, name=name)

    def send(self, message: str) -> int:
        data: bytes = message.encode("utf-8")
        bytes_sent: int = 0
        bytes_sent = self.client_socket.send(data)
        return bytes_sent

    def recv(self, size: int) -> str:
        data: bytes = self.client_socket.recv(size)
        msg: str = data.decode("utf-8")
        return msg
    
    def take_image(self, fname: str):
        self.camera.capture_image(fname)
    
    def exec(self, msg: str) -> None:
        sub_strings: List[str] = msg.split(',')
        cmd: str = sub_strings[0]
        args: List[str] = []
        if len(sub_strings) > 1:
            args = sub_strings[1:]
        match cmd.upper():
            case 'NEW-FOLDER':
                os.makedirs(args[0])
            case 'TAKE-IMAGE':
                self.take_image(*args)
            case 'ANALYZE-IMAGES':
                analyze_run(*args)
            case _:
                pass
        return


    def __exit__(self, exc_type, exc_val, traceback):
        self.camera.close()
        super().__exit__(exc_type, exc_val, traceback)

if __name__ == '__main__':
    cam_server: CameraServer = CameraServer(name='RAISE_VISION_SERVER', 
                                            port=1200, 
                                            cam_idx=0, 
                                            camera_name='Camera 1')
    
    with cam_server as cs:
        while True:
            msg: str = cs.recv(1024)
            cs.exec(msg)
            cs.send('Task Complete')

